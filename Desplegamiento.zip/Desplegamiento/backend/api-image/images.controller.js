const multer = require("multer");
const path = require("path");
const fs = require("fs");
let uploadedFileName;

const storage = multer.diskStorage({
  destination: path.join(__dirname, "../images"),
  filename: (req, file, cb) => {
    // Generar el nombre de archivo único
    const uniqueName =
      Date.now() +
      "-" +
      Math.round(Math.random() * 1e9) +
      path.extname(file.originalname);
    cb(null, file.originalname);
  },
});

exports.getImage = (req, res) => {
  let imageName = req.params.filename;
  if (imageName === "undefined") {
    imageName = "null.png"; // ruta de la imagen por defecto
  }
  const imagePath = path.join(__dirname, "../images", imageName);

  fs.readFile(imagePath, (err, data) => {
    if (err) {
      console.error(err);
      res.status(404).send("Image not found");
    } else {
      res.writeHead(200, { "Content-Type": "image/png" });
      res.write(data);
      res.end();
    }
  });
};

exports.getAnuncioImages = (req, res) => {
  req.getConnection((err, conn) => {
    const sql =
      "SELECT MIN(id) AS id, productos_id, name FROM image GROUP BY productos_id, name";
    conn.query(sql, (err, results) => {
      if (err) {
        console.log(err);
        res.sendStatus(500);
      } else {
        res.json(results);
      }
    });
  });
};

exports.deleteImage = (req, res) => {
  const imageId = req.params.id;

  req.getConnection((err, conn) => {
    if (err) {
      console.log(err);
      res.sendStatus(500);
      return;
    }

    const sql = "SELECT name FROM image WHERE id = ?";
    conn.query(sql, [imageId], (err, results) => {
      if (err) {
        console.log(err);
        res.sendStatus(500);
        return;
      }

      if (results.length === 0) {
        res.sendStatus(404);
        return;
      }

      const imageName = results[0].name;
      const imagePath = path.join(__dirname, "../images", imageName);

      fs.unlink(imagePath, (err) => {
        if (err) {
          console.log(err);
          res.sendStatus(500);
          return;
        }

        const deleteSql = "DELETE FROM image WHERE id = ?";
        conn.query(deleteSql, [imageId], (err, results) => {
          if (err) {
            console.log(err);
            res.sendStatus(500);
          } else {
            // Desactivar la caché
            res.setHeader(
              "Cache-Control",
              "no-cache, no-store, must-revalidate"
            );
            res.setHeader("Pragma", "no-cache");
            res.setHeader("Expires", "0");

            res.sendStatus(200);
          }
        });
      });
    });
  });
};

exports.updateImage = (req, res) => {
  const imageId = req.params.id;

  req.getConnection((err, conn) => {
    if (err) {
      console.log(err);
      res.sendStatus(500);
      return;
    }

    // Verificar si hay un archivo en la solicitud
    if (!req.file) {
      res.status(400).json({ error: "No se ha seleccionado un archivo" });
      return;
    }

    const sql = "SELECT name FROM image WHERE id = ?";
    conn.query(sql, [imageId], (err, results) => {
      if (err) {
        console.log(err);
        res.sendStatus(500);
        return;
      }

      if (results.length === 0) {
        res.sendStatus(404);
        return;
      }

      const oldImageName = results[0].name;
      const oldImagePath = path.join(__dirname, "../images", oldImageName);

      // Borrar la imagen anterior del sistema de archivos utilizando fs.unlink
      fs.unlink(oldImagePath, (err) => {
        if (err) {
          console.log(err);
          res.sendStatus(500);
          return;
        }

        // Generar un nombre único para el nuevo archivo
        const uniqueName =
          Date.now() +
          "-" +
          Math.round(Math.random() * 1e9) +
          path.extname(req.file.originalname);

        const newImagePath = path.join(__dirname, "../images", uniqueName);

        // Mover el nuevo archivo al directorio de imágenes
        fs.rename(req.file.path, newImagePath, (err) => {
          if (err) {
            console.log(err);
            res.sendStatus(500);
            return;
          }

          // Actualizar la entrada de la base de datos con el nuevo nombre de archivo
          const updateSql = "UPDATE image SET name = ? WHERE id = ?";
          conn.query(updateSql, [uniqueName, imageId], (err, results) => {
            if (err) {
              console.log(err);
              res.sendStatus(500);
            } else {
              // Desactivar la caché
              res.setHeader(
                "Cache-Control",
                "no-cache, no-store, must-revalidate"
              );
              res.setHeader("Pragma", "no-cache");
              res.setHeader("Expires", "0");

              res.sendStatus(200);
            }
          });
        });
      });
    });
  });
};

exports.getAnuncioImagesId = (req, res) => {
  const anuncioId = req.params.id; // Obtener el ID del anuncio desde los parámetros de la solicitud

  req.getConnection((err, conn) => {
    if (err) {
      console.log(err);
      res.sendStatus(500);
      return;
    }

    const sql =
      "SELECT id, productos_id, name FROM image WHERE productos_id = ?";
    conn.query(sql, [anuncioId], (err, results) => {
      if (err) {
        console.log(err);
        res.sendStatus(500);
      } else {
        const images = results.map((result) => result.name); // Obtener solo los nombres de las imágenes
        res.json(images);
      }
    });
  });
};

exports.getAnuncioImagesData = (req, res) => {
  const anuncioId = req.params.id; // Obtener el ID del anuncio desde los parámetros de la solicitud

  req.getConnection((err, conn) => {
    if (err) {
      console.log(err);
      res.sendStatus(500);
      return;
    }

    const sql =
      "SELECT id, productos_id, name FROM image WHERE productos_id = ?";
    conn.query(sql, [anuncioId], (err, results) => {
      if (err) {
        console.log(err);
        res.sendStatus(500);
      } else {
        res.json(results); // Enviar los resultados de la consulta como JSON
      }
    });
  });
};

const upload = multer({ storage: storage });

exports.upload = upload.array("images", 5);

exports.uploadFile = (req, res) => {
  req.getConnection((err, conn) => {
    if (err) return res.send(err);

    // Verificar si hay archivos en la solicitud
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: "No se han seleccionado archivos" });
    }

    // Obtener la ID del producto desde los parámetros de la URL
    const productos_id = req.params.id;

    // Procesar cada archivo y guardarlos en la base de datos
    for (let i = 0; i < req.files.length; i++) {
      const file = req.files[i];
      const type = file.mimetype;
      const name = file.originalname;

      // Crear un stream de lectura para la imagen
      const currentDate = new Date().toISOString().split("T")[0];

      const imageData = { type, name, date: currentDate, productos_id };

      conn.query(
        "INSERT INTO " + req.params.tabla + " SET ?",
        imageData,
        (err, rows) => {
          if (err) {
            console.log("Error al insertar imagen:", err);
          } else {
            console.log("Imagen insertada correctamente:", imageData.name);
          }
        }
      );
    }

    res.json({ msg: "Imágenes cargadas satisfactoriamente" });
  });
};
