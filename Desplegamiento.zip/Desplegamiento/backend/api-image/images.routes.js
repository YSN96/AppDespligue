const express = require("express");
const routes = express.Router();

const imagesController = require("./images.controller");

routes.post(
  "/images/:tabla/:id",
  imagesController.upload,
  imagesController.uploadFile
);

routes.get("/images/anuncios", imagesController.getAnuncioImages);
routes.get("/images/anuncio/:id", imagesController.getAnuncioImagesId);
routes.get("/images/:filename", imagesController.getImage);
routes.get("/images/anuncio/all/:id", imagesController.getAnuncioImagesData);
routes.delete("/images/delete/:id", imagesController.deleteImage);
routes.put("/images/update/:id", imagesController.updateImage);
module.exports = routes;
