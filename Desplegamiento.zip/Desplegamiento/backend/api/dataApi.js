const models = require("../db/db");
const express = require("express");
const router_datos = express.Router();
const mysql = require("mysql2");

const { authenticateToken } = require("./functions");

let conexion = mysql.createConnection(models.mysql);
conexion.connect();
conexion.on("error", (err) => {
  console.log("Re-connecting lost conn: ");
  conexion = mysql.createConnection(models.mysql);
});

router_datos.get("/productos", (req, res) => {
  const sql = "SELECT * FROM productos ORDER BY fecha_publicacion DESC";
  conexion.query(sql, (error, results) => {
    if (error) throw error;
    res.json(results);
  });
});

router_datos.put("/productos/:id", authenticateToken, (req, res) => {
  const id = req.params.id;
  const {
    nombre_producto,
    descripcion,
    ubicacion,
    precio,
    km,
    numero_contacto,
    estado,
    marca,
    anno,
    puertas,
    color,
    cambio,
  } = req.body;

  const sql =
    "UPDATE productos SET nombre_producto = ?, descripcion = ?, ubicacion = ?, precio = ?, km = ?, numero_contacto = ?, estado = ?, marca = ?, anno = ?, puertas = ?, color = ?, cambio = ? WHERE id = ?";
  const values = [
    nombre_producto,
    descripcion,
    ubicacion,
    precio,
    km,
    numero_contacto,
    estado,
    marca,
    anno,
    puertas,
    color,
    cambio,
    id,
  ];

  conexion.query(sql, values, (error, results) => {
    if (error) throw error;
    res.json({ message: "Producto actualizado correctamente" });
  });
});

router_datos.get("/productos/:userId", authenticateToken, (req, res) => {
  const userId = req.params.userId;
  const sql =
    "SELECT * FROM productos WHERE user_id = ? ORDER BY fecha_publicacion DESC";
  conexion.query(sql, [userId], (error, results) => {
    if (error) throw error;
    res.json(results);
  });
});

router_datos.get("/productos/solitario/:productId", (req, res) => {
  const productId = req.params.productId;
  const sql = "SELECT * FROM productos WHERE id = ?";
  conexion.query(sql, [productId], (error, results) => {
    if (error) throw error;
    res.json(results);
  });
});

router_datos.delete("/productos/:productId", authenticateToken, (req, res) => {
  const productId = req.params.productId;
  const sql = "DELETE FROM productos WHERE id = ?";
  conexion.query(sql, [productId], (error, results) => {
    if (error) throw error;
    res.json({ message: "Producto eliminado correctamente" });
  });
});

router_datos.post("/productos", authenticateToken, (req, res) => {
  const {
    id,
    nombre_producto,
    descripcion,
    precio,
    km,
    numero_contacto,
    marca,
    ubicacion,
    anno,
    puertas,
    color,
    cambio,
    user_id,
  } = req.body;

  // Set initial value of 'visitas' to 0
  const visitas = 0;

  const sql =
    "INSERT INTO productos (id, nombre_producto, descripcion, precio, km, numero_contacto, marca, ubicacion, anno, puertas, color, cambio, user_id, visitas) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  const values = [
    id,
    nombre_producto,
    descripcion,
    precio,
    km,
    numero_contacto,
    marca,
    ubicacion,
    anno,
    puertas,
    color,
    cambio,
    user_id,
    visitas,
  ];

  conexion.query(sql, values, (error, result) => {
    if (error) {
      console.error(error);
      res.status(500).send("Error al insertar el producto");
      return;
    }
    console.log(`Producto añadido con ID: ${values[0]}`);
    res.status(201).send(`Producto añadido con ID: ${values[0]}`);
  });
});

router_datos.put("/visitas/:productoId/", (req, res) => {
  const { productoId } = req.params;

  const sql = "UPDATE productos SET visitas = visitas + 1 WHERE id = ?";
  const values = [productoId];

  conexion.query(sql, values, (error, result) => {
    if (error) {
      console.error(error);
      res.status(500).send("Error al actualizar las visitas del producto");
      return;
    }
    console.log(`Visitas actualizadas para el producto con ID: ${productoId}`);
    res
      .status(200)
      .send(`Visitas actualizadas para el producto con ID: ${productoId}`);
  });
});

router_datos.get("/valoraciones", authenticateToken, (req, res) => {
  const sql = `
  SELECT user_data.valoracion, user_data.mensaje, user.username, user.email 
  FROM user_data 
  JOIN user ON user_data.user_id = user.id 
  ORDER BY user_data.id DESC
  LIMIT 4
`;

  conexion.query(sql, (err, results) => {
    if (err) {
      console.log(err);
      res.sendStatus(500);
    } else {
      res.json(results);
    }
  });
});

router_datos.post("/valoracionesusuario", authenticateToken, (req, res) => {
  const { valoracion, mensaje, user_id } = req.body; // Obtener los datos de la valoración desde el cuerpo de la solicitud

  const sql =
    "INSERT INTO user_data (valoracion, mensaje, user_id) VALUES (?, ?, ?)";
  const values = [valoracion, mensaje, user_id]; // Utilizar req.user.id para obtener el ID del usuario autenticado

  conexion.query(sql, values, (err, result) => {
    if (err) {
      console.log(err);
      res.sendStatus(500);
    } else {
      res.sendStatus(200);
    }
  });
});

router_datos.get("/valoracionesid/:id", (req, res) => {
  const userId = req.params.id; // Obtener el user_id desde los parámetros de la URL

  const sql = `
    SELECT user_data.valoracion, user_data.mensaje, user.username, user.email 
    FROM user_data 
    JOIN user ON user_data.user_id = user.id 
    WHERE user_data.user_id = ?
    ORDER BY user_data.id DESC
  `;
  const values = [userId];

  conexion.query(sql, values, (err, results) => {
    if (err) {
      console.log(err);
      res.sendStatus(500);
    } else {
      res.json(results);
    }
  });
});

module.exports = router_datos;
