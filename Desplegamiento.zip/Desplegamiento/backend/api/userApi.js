const models = require("../db/db");
const express = require("express");
const router_usuario = express.Router();
const mysql = require("mysql2");
const $sql = require("../db/sqlMap");

const { getAuthConfig } = require("./functions");
const { authenticateToken } = require("./functions");

const authConfig = getAuthConfig();

let conexion = mysql.createConnection(models.mysql);
conexion.connect();
conexion.on("error", (err) => {
  console.log("Re-connecting lost conn: ");
  conexion = mysql.createConnection(models.mysql);
});

router_usuario.post("/login", (req, res) => {
  const user = req.body;
  const sel_username =
    $sql.user.select + " WHERE username = '" + user.username + "'";
  conexion.query(sel_username, (error, results) => {
    if (error) {
      console.log(error);
      return res.json({
        code: "-1",
        message: "Error",
      });
    }
    console.log(results);
    if (results[0] === undefined) {
      return res.json({
        code: "-1",
        message: "Nombre Usuario Incorrecto",
      });
    } else {
      if (parseInt(Date.now() / 1000) - results[0].block_time < 300) {
        return res.json({
          code: "2",
          message: "Account blocked. Please wait",
        });
      } else if (
        results[0].username == user.username &&
        results[0].password == user.password
      ) {
        const token = authConfig.jwt.sign(
          { username: user.username },
          authConfig.jwtSecret
        );
        console.log(token);
        return res.json({
          code: "0",
          message: "Login successful",
          token: token,
          id: results[0].id,
        });
      } else {
        if (results[0].failed_times >= 4) {
          conexion.query(
            $sql.user.update_failed_times,
            [0, user.username],
            (error, updateResults) => {
              if (error) {
                console.log(error);
                return res.json({
                  code: "-1",
                  message: "An error occurred",
                });
              } else {
                console.log(Date.now());
                conexion.query(
                  $sql.user.update_block_time,
                  [parseInt(Date.now() / 1000), user.username],
                  (error, blockResults) => {
                    if (error) {
                      console.log(error);
                      return res.json({
                        code: "-1",
                        message: "An error occurred",
                      });
                    } else {
                      return res.json({
                        code: "2",
                        message: "Account blocked. Please wait",
                      });
                    }
                  }
                );
              }
            }
          );
        } else {
          conexion.query(
            $sql.user.update_failed_times,
            [results[0].failed_times + 1, user.username],
            (error, updateResults) => {
              if (error) {
                return res.json({
                  code: "-1",
                  message: "La contraseña es incorrecta",
                });
              } else {
                return res.json({
                  code: "1",
                  message: "Incorrect password",
                });
              }
            }
          );
        }
      }
    }
  });
});

router_usuario.post("/add", (req, res) => {
  const params = req.body;
  const selUsernameSql =
    $sql.user.select + " WHERE username = '" + params.username + "'";
  const selEmailSql =
    $sql.user.select + " WHERE email = '" + params.email + "'";
  const addSql = $sql.user.add;

  conexion.query(selUsernameSql, (error, usernameResults) => {
    if (error) {
      console.log(error);
      return res.json({
        code: "-1",
        message: "An error occurred",
      });
    }

    if (
      usernameResults.length !== 0 &&
      params.username === usernameResults[0].username
    ) {
      return res.json({
        code: "-1",
        message: "Username already occupied",
      });
    }

    conexion.query(selEmailSql, (emailError, emailResults) => {
      if (emailError) {
        console.log(emailError);
        return res.json({
          code: "-1",
          message: "An error occurred",
        });
      }

      if (emailResults.length !== 0 && params.email === emailResults[0].email) {
        return res.json({
          code: "-1",
          message: "Email already exists",
        });
      }

      conexion.query(
        addSql,
        [params.username, params.email, params.password],
        (err, rst) => {
          if (err) {
            console.log(err);
            return res.json({
              code: "-1",
              message: "An error occurred",
            });
          }

          console.log(rst);
          return res.json({
            code: "0",
            message: "Registration succeeded",
          });
        }
      );
    });
  });
});

router_usuario.get("/userdetails", authenticateToken, (req, res) => {
  const username = req.query.username;

  const sql = $sql.user.select + " where username = ?";
  const values = [username];

  conexion.query(sql, values, (error, results) => {
    if (error) {
      console.log(error);
      res.json({
        code: "-1",
        message: "error",
      });
    } else if (results.length == 0) {
      res.json({
        code: "-1",
        message: "no user found",
      });
    } else {
      const user = results[0];
      res.json({
        code: "0",
        message: "success",
        data: {
          username: user.username,
          email: user.email,
          password: user.password,
        },
      });
    }
  });
});

router_usuario.get("/userdetailsid/:id", (req, res) => {
  const userId = req.params.id;

  const sql = $sql.user.select + " where id = ?";
  const values = [userId];

  conexion.query(sql, values, (error, results) => {
    if (error) {
      console.log(error);
      return res.json({
        code: "-1",
        message: "error",
      });
    }

    if (results.length === 0) {
      return res.json({
        code: "-1",
        message: "user found",
      });
    }

    const user = results[0];
    res.json({
      code: "0",
      message: "success",
      data: {
        id: user.id,
        username: user.username,
        email: user.email,
      },
    });
  });
});

router_usuario.get("/userdetailstotal", (req, res) => {
  const sql = $sql.user.select;

  conexion.query(sql, (error, results) => {
    if (error) {
      console.log(error);
      return res.json({
        code: "-1",
        message: "error",
      });
    }

    const count = results.length;

    if (count === 0) {
      return res.json({
        code: "-1",
        message: "No users found",
      });
    }

    const users = results.map((user) => ({
      id: user.id,
      username: user.username,
      email: user.email,
    }));

    res.json({
      code: "0",
      message: "success",
      count: count,
      data: users,
    });
  });
});

router_usuario.put("/updateuser", authenticateToken, (req, res) => {
  const username = req.body.username;
  const email = req.body.email;

  const checkEmailSql = "SELECT * FROM user WHERE email = ?";
  const checkEmailValues = [email];

  conexion.query(
    checkEmailSql,
    checkEmailValues,
    (checkEmailError, checkEmailResults) => {
      if (checkEmailError) {
        console.log(checkEmailError);
        res.json({
          code: "-1",
          message: "error",
        });
      } else if (checkEmailResults.length > 0) {
        res.json({
          code: "-1",
          message: "email already exists",
        });
      } else {
        const updateSql = "UPDATE user SET email = ? WHERE username = ?";
        const updateValues = [email, username];

        conexion.query(
          updateSql,
          updateValues,
          (updateError, updateResults) => {
            if (updateError) {
              console.log(updateError);
              res.json({
                code: "-1",
                message: "error",
              });
            } else {
              res.json({
                code: "0",
                message: "success",
              });
            }
          }
        );
      }
    }
  );
});

router_usuario.get("/logout", (req, res) => {
  res.json({ message: "Session cerrada" });
});

module.exports = router_usuario;
