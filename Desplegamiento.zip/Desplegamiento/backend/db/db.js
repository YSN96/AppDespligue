module.exports = {
  mysql: {
    host: "mysql",
    user: "root",
    password: "",
    port: "3306",
    database: "healthcare",
  },
};
