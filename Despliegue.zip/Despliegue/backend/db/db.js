module.exports = {
    mysql: {
        host: 'db',
        user: 'root',
        password: '',
        port: '3306',
        database: 'cena'
    }
}
